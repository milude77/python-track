# 代码演练

## Python演练广场

---

**Python即时练习环境** - 这是一个Python代码演练场，你可以：


```mermaid
classDiagram
    direction LR
    class MessageService {
        <<interface>>
        +sendMessage(msg: String)
    }
    class EmailService {
        +sendMessage(msg: String)
    }
    class SMSService {
        +sendMessage(msg: String)
    }
    class MessageClient {
        -messageService: MessageService
        +sendMessage(message: String)
    }
    class DIContainer {
        -services: Map~Class, Any~
        +register~T~(serviceClass: Class~T~, implementation: T)
        +get~T~(serviceClass: Class~T~) T
    }
    MessageService <|.. EmailService
    MessageService <|.. SMSService
    MessageClient --> MessageService
    DIContainer --> MessageService
```
- ⚡ 快速输出结果
- 💻 离线运行代码
- ⏳ 无AI响应延迟
